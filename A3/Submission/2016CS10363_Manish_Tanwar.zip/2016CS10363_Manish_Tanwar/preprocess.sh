python3 2/2a.py $1 $3
python3 2/2a.py $2 $4